# JadwalSholatOrg

Parsed data from website https://jadwalsholat.org

## Usage

### Cities

https://raw.githubusercontent.com/lakuapik/jadwalsholatorg/master/kota.json

### Jadwal Sholat

#### Monthly
using raw github: https://raw.githubusercontent.com/lakuapik/jadwalsholatorg/master/adzan/semarang/2019/12.json  
or using cdn: https://cdn.statically.io/gh/lakuapik/jadwalsholatorg/master/adzan/semarang/2019/12.json

#### Daily
* previously, it has daily schedule. but now it is deleted to make the repo lighter.
* please choose monthly schedule. the size only different in KiloByte.
