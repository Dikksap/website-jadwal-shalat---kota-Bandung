
<link rel="stylesheet" href="style.css">
  <!-- Fontawesome CDN Link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
   <nav>
    <div class="container mt-2">
      <div class="">
        <img src="../moon.png" width="40px">
        
</div>
<div class="container">
  <a href="#" class="text-start" style="text-decoration: none; color :white; font-size:40px;">MUSLIMIN</a> 
</div>
      <div class="hamburger-menu" onclick="toggleMenu()">
        <div class="bar"></div>
        <div class="bar"></div>
        <div class="bar"></div>
      </div>
      <ul class="menu">
        <li><a href="../page/">Home</a></li>
        <li class="dropdown">
          <a href="../page" class="dropdown-item">Jadwal Shalat</a>
        </li>
        <li class="dropdown">
          <a href="#" class="dropdown-item">Kumpulan Hadits Shahih</a>
        </li>
        <li class="dropdown">
          <a href="#" class="dropdown-item">Kisah Muslim</a>
        </li>
        <li><a href="qur'an.php">Qur'an</a></li>
      </ul>
    </div>
  </nav>
<script src="script.js"></script>
