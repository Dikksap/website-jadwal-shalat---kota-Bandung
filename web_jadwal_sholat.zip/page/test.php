<?php include_once('fungsi.php'); ?>
<?php

$surat = $data_ayat['data']['name_id'];
$terjemah = $data_ayat['data']['translation_id'];
$relevansi = $data_ayat['data']['revelation_id'];
?>


<!doctype html>
<html lang="id">
<head>
<title>Al-Quran Surah Al-Fatihah Terjemahan dan Tafsir Bahasa Indonesia</title>
<meta charset="utf-8">
<meta name="google" content="notranslate">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta property="og:title" content="Al-Quran Surah Al-Fatihah Terjemahan dan Tafsir Bahasa Indonesia">
<meta property="og:description" content="Al-Quran Surah Al-Fatihah merupakan surah ke-1 yang terdiri dari 7 ayat. Lengkap dengan terjemahan dan tafsir Bahasa Indonesia">
<meta property="og:url" content="/1/">
<meta property="og:image" content="https://s3-ap-southeast-1.amazonaws.com/quranweb/quranweb-1024.png">
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-128871246-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-128871246-1');
</script>
<meta name="keywords" content="al-quran, terjemahan, surah Al-Fatihah">
<meta name="description" content="Al-Quran Surah Al-Fatihah merupakan surah ke-1 yang terdiri dari 7 ayat. Lengkap dengan terjemahan dan tafsir Bahasa Indonesia">
<style>
@font-face {
    font-family: "LPMQ";
    src: url("/fonts/lpmq.otf?v=1.7.2") format("opentype");
    font-display: swap;
}
html {
    height: 100%;
}
* {
    margin: 0;
    padding: 0;
}
body {
    font-family: "Georgia", "Arial", "Serif";
    width: 100%;
    color: #444;
    position: relative;
    min-height: 100%;
    box-sizing: border-box;
}
a, a:visited {
    text-decoration: none;
    color: inherit;
}
.header {
    width: 100%;
    box-sizing: border-box;
    display: block;
    text-align: center;
    margin-bottom: 5em;
    position: relative;
}
.header h1 {
    font-size: 1.3em;
    margin: 0 auto;
    font-weight: normal;
}
.surah-number-name {
    border-radius: 30px;
    background-color: #444;
    margin-right: 0.4em;
    color: white;
    font-size: 0.7em;
    padding: 0.1em 0.5em 0.2em 0.5em;
    top: -0.2em;
    position: relative;
}
.header h2.surah-count {
    font-size: 1em;
    font-weight: normal;
}
.header h2.page-name {
    padding-top: 0.7em;
    font-weight: normal;
    font-size: 0.9em;
    margin-bottom: 1.4em;
}
.menu {
    box-sizing: border-box;
    position: absolute;
    left: 0;
    top: 0;
    z-index: 10;
}
.linemenu {
    width: 24px;
    height: 4px;
    background-color: #444;
    margin: 4px 0;
    display: block;
}
.page-wrapper {
    padding-left: 1em;
    padding-right: 1em;
}
.page-heading {
    font-size: 1.3em;
    font-weight: normal;
    margin-bottom: 0.5em;
    padding-bottom: 0.3em;
    border-bottom: 1px solid #f1f1f1;
}
.page-wrapper p {
    line-height: 1.5em;
    margin-bottom: 0.5em;
}
.page-wrapper ul {
    margin-left: 1em;
    list-style: none;
}
.page-wrapper li {
    line-height: 1.5em;
}
.page-wrapper li:before {
    content: "•";
    padding-right: 0.5em;
}
.page-wrapper a {
    color: black;
}
.goto-ayah-wrapper {
    width: 100%;
    position: absolute;
    top: -2.4em;
    text-align: center;
}
.label-goto-ayah {
    font-size: 0.9em;
    display: inline;
}
.goto-ayah {
    appearance: none;
    -moz-appearance: none;
    -webkit-appearance: none;
    padding: 0.2em 0.5em;
    border: 1px solid #e4e4e4;
    border-top: none;
    border-right: none;
    border-left: none;
    width: 3em;
    font-size: 0.8em;
}
.ayah-toolbar {
    margin: 0.5em 0 2.8em 0;
    position: relative;
    width: 100%;
    box-sizing: border-box;
    text-align: right;
}
.icon-ayah-toolbar {
    box-sizing: border-box;
    width: 1.8em;
    height: 1.8em;
    background-color: #f1f1f1;
    font-family: sans-serif;
    display: table;
    float: right;
    text-align: center;
    margin-left: 0.3em;
    cursor: pointer;
}
.icon-content {
    display: table-cell;
    vertical-align: middle;
}
.icon-tafsir-ayah {
    padding-top: 0.1em;
}
.ayah-wrapper {
    width: 100%;
    padding-bottom: 5em;
    box-sizing: border-box;
    border-radius: 0.5em;
    position: relative;
}
.search-wrapper {
    width: 99%;
    box-sizing: border-box;
    position: inherit;
    margin-bottom: 1em;
}
.search-keywords {
    width: 100%;
    border-radius: 4px;
    font-size: 1.2em;
    border: none;
    border-bottom: 1px solid #f1f1f1;
    box-sizing: border-box;
    padding: 0.2em 0.5em;
    font-family: "Georgia", "Arial", "Serif";
    color: #444;
}
.ayah {
    margin-bottom: 0.5em;
}
.ayah-text {
    font-family: "LPMQ", "Arial", "Verdana", "Serif";
    font-size: 1.6em;
    background-color: #f1f1f1;
    position: relative;
}
.ayah-text p {
    padding: 0.5em 0.5em 0.5em 0.3em;
    line-height: 3em;
}
.ayah-translation {
    font-size: 1em;
    font-style: italic;
    padding: 1em 0em 2em;
}
.ayah-translation p {
    padding: 0.2em 0.2em 0.2em 0.5em;
    line-height: 1.8em;
}
.ayah-tafsir-wrapper {
    position: relative;
    box-sizing: border-box;
    padding: 0.2em 0.2em 0.2em 0.5em;
}
.ayah-tafsir-title {
    font-size: 1.3em;
    font-weight: normal;
    padding-bottom: 0.5em;
    border-bottom: 1px solid #e4e4e4;
}
.ayah-tafsir {
    font-size: 1em;
    padding: 1em 0.5em 0.5em 0em;
    line-height: 1.8em;
    /*white-space: pre-wrap;*/
}
.ayah-tafsir-source {
    font-size: 0.6em;
    font-style: italic;
    padding: 1em 0.5em 0.5em 0em;
    margin-top: 1em;
}
.ayah-prev-next-wrapper {
    position: relative;
    font-family: sans-serif;
    font-size: 1.5em;
    z-index: 5;
}
.ayah-prev-next-wrapper.bottom {
    margin-bottom: 2em;
    display: block;
}
.ayah-prev {
    position: absolute;
    top: -1.9em;
    left: 0.2em;
}
.ayah-next {
    position: absolute;
    top: -1.9em;
    right: 0.2em;
}
.ayah-prev.bottom,
.ayah-next.bottom {
    top: 0;
}
.ayah-number {
    font-size: 0.5em;
    padding: 0.1em 0.3em;
    background-color: #ccc;
    position: absolute;
    line-height: 1.5em;
    top: 0;
    left: 0;
    font-family: sans-serif;
}
.surah-list {
    box-sizing: border-box;
}
.surah-index {
    list-style: none;
    padding: 0.5em 0.2em 0.5em 1em;
    margin-bottom: 0.5em;
    background-color: #f1f1f1;
    position: relative;
    display: block;
}
.surah-index-name {
    display: block;
    font-size: 1.2em;
}
.surah-index-ayah {
    display: block;
    font-size: 0.75em;
}
.surah-index-number {
    position: absolute;
    font-size: 1.2em;
    right: 0.6em;
    top: 0.5em;
}
.footer {
    position: absolute;
    right: 0;
    bottom: 0;
    left: 0;
    padding: 1em 0.5em;
    text-align: center;
    border-top: 1px solid #e4e4e4;
    color: #666;
    box-sizing: border-box;
}
.footer p {
    font-size: 0.8em;
    line-height: 1.5em;
}
.footer p a,
.footer p a:visited {
    text-decoration: none;
}
@media screen and (min-width: 720px) {
    .ayah-wrapper {
        width: 720px;
        margin: 0 auto;
    }
    .ayah-wrapper .ayah .ayah-translation p {
        padding: 0.2em 0.2em 0.2em 0em;
    }
    .goto-ayah-wrapper {
        padding-right: 0;
    }
    .ayah-tafsir-wrapper {
        padding-left: 0;
    }
    .ayah-prev {
        left: 0;
    }
    .ayah-next {
        right: 0;
    }
}
.sidepage {
    width: 100%;
    position: absolute;
    left: 0;
    top: 0;
    z-index: 10;
    box-sizing: border-box;
    height: 100%;
    min-height: 100%;
    background-color: #f1f1f1;
    padding-top: 2em;
    padding-right: 2em;
    display: none;
}
.sidepage-item {
    box-sizing: border-box;
    padding: 0.8em 0.3em;
    font-size: 1.2em;
    margin-left: 1em;
    border-bottom: 1px solid #ccc;
}
.sidepage-close {
    padding: 0.5em;
    position: absolute;
    top: 0;
    right: 1em;
    background-color: black;
}
.sidepage-close a,
.sidepage-close a:visited {
    color: #f1f1f1;
    text-decoration: none;
    font-size: 1.5em;
}
.sidepage .settings span {
    margin-right: 1em;
    display: block;
    margin-bottom: 0.5em;
}
.sidepage-subitem {
    font-size: 0.7em;
    box-sizing: border-box;
    padding: 0;
    border-radius: 0.5em;
    margin-top: 1em;
}
.sidepage-item-last-marked {
    display: block;
    font-size: 0.7em;
    margin-top: 0.5em;
}
.sidepage:target {
    display: block;
}
.sidepage-textbox-for-radio {
    padding: 0.2em;
    width: 75%;
    border: none;
    border-bottom: 1px solid #e4e4e4;
}
.murottal-reciter {
    appearance: none;
    -moz-appearance: none;
    -webkit-appearance: none;
    padding: 0.2em 0.5em 0.2em 0.5em;
    border: 1px solid #e4e4e4;
    border-top: none;
    border-right: none;
    border-bottom: none;
    width: 75%;
}
.input-error {
    color: #c60000;
    border-bottom: 1px solid #c60000;
}
.hide {
    display: none;
}
.report-error-message:target {
    display: block;
}
.margin-bottom-2,
p.margin-bottom-2 {
    margin-bottom: 2em;
}
.margin-bottom-half {
    margin-bottom: 0.5em
}
.margin-top-1 {
    margin-top: 1em;
}

/* Begin Night Mode Specs */
.nightmode, .nightmode > div, .nightmode input, .nightmode select, .nightmode option {
    background-color: #222;
    color: #a9a9a9;
    border-color: #444;
}

.nightmode .surah-index, .nightmode .ayah-text, .nightmode .icon-ayah-toolbar {
    background-color: #333;
}

.nightmode .linemenu {
    background-color: #a9a9a9;
}

.nightmode .sidepage-item, .nightmode .ayah-tafsir-title, .nightmode .page-heading {
    border-color: #444;
}

.nightmode .ayah-number {
    background-color: #222;
}

.nightmode .page-wrapper a {
    color: #f1f1f1;
}

/* Begin Hide Translation Specs */
.notranslation .ayah-translation {
    display: none;
}
</style>
</head>
<body>

<div class="header">
    <h2 class="page-name">Surah</h2>
    <h1 class="surah-name"><span class="surah-number-name">1</span><?= $surat ?></h1>
    <h2 class="surah-count">7 Ayat</h2>
</div>

<div class="menu">
    <a title="Klik untuk membuka menu" href="#sidepage">
        <span class="linemenu"></span>
        <span class="linemenu"></span>
        <span class="linemenu"></span>
    </a>
</div>

<div id="sidepage" class="sidepage">
    <div class="sidepage-close"><a title="Tutup menu" href="#">X</a></div>
    <div class="sidepage-item settings">
        <span><input id="translation" class="checkbox" type="checkbox" checked=""> <label title="Aktifkan atau non-aktifkan terjemahan ayat" for="translation">Terjemahan</label></span>
        <span><input id="nightmode" class="checkbox" type="checkbox"> <label title="Aktifkan atau non-aktifkan tampilan mode malam" for="nightmode">Mode Malam</label></span>
    </div>
    <div class="sidepage-item">
        <a title="Buka halaman daftar surah" href="/" class="sidepage-item-link"><span>Daftar Surah</span></a>
    </div>
    <div class="sidepage-item">
        <a title="Buka ayat yang terakhir dibaca" href="#" class="sidepage-item-link" id="last-read-link">
            <span>Terakhir Dibaca</span>
            <span id="sidepage-item-last-marked" class="sidepage-item-last-marked">Belum Ada. Click pada simbol &#x2713; untuk menandai.</span>
        </a>
    </div>
    <div class="sidepage-item settings">
        <a title="Audio murottal tiap ayat" class="sidepage-item-link">Audio Murottal</a>
        <span class="sidepage-subitem"><input id="murottal-mode-noloop" name="murottal-mode" class="checkbox" type="radio" checked value="noloop"> <label title="Berhenti ketika ayat selesai" for="murottal-mode-noloop">Tidak diulang</label></span>
        <span class="sidepage-subitem"><input id="murottal-mode-loop-ayah" name="murottal-mode" class="checkbox" type="radio" value="ayah"> <label title="Ulang murottal pada ayat" for="murottal-mode-loop-ayah">Ulangi ayat</label></span>
        <span class="sidepage-subitem"><input id="murottal-mode-loop-ayah-selection" name="murottal-mode" class="checkbox" type="radio" value="ayah-selection"> <label title="Ulang murottal pada ayat" for="murottal-mode-loop-ayah-selection">Ulangi ayat pilihan</label></span>
        <span class="sidepage-subitem"><input id="ayah-selection-input" type="text" class="sidepage-textbox-for-radio" placeholder="Contoh: 5,6,11-15,20,22"></span>
        <span class="sidepage-subitem"><input id="murottal-mode-loop-surah" name="murottal-mode" class="checkbox" type="radio" value="surah"> <label title="Ulang murottal pada surah" for="murottal-mode-loop-surah">Ulangi surah</label></span>
        <span class="sidepage-subitem">
            <select id="murottal-reciter" name="murottal-reciter" class="murottal-reciter" title="Pilih nama qori">
                <option value="Abdurrahmaan_As-Sudais_192kbps">Sheikh Abdurrahman As-Sudais</option>
                <option value="Husary_128kbps">Sheikh Mahmoud Khalil Al-Hussary</option>
                <option value="Alafasy_128kbps">Sheikh Mishary Rashid Alafasy</option>
            </select>
        </span>
    </div>
    <div class="sidepage-item">
        <a title="Buka halaman tentang QuranWeb" href="/tentang/" class="sidepage-item-link"><span>Tentang QuranWeb</span></a>
    </div>
    <div class="sidepage-item">
        <a title="Buka halaman Github dari QuranWeb" href="https://github.com/rioastamal/quran-web" class="sidepage-item-link"><span>Github</span></a>
    </div>
</div>


<!-- Begin each ayah -->
<div class="ayah-wrapper">

    <div class="ayah-prev-next-wrapper">
        <a title="Sebelumnya Surah An-Nas" class="ayah-prev" href="/114/">&larr;</a>
        <a title="Berikutnya Surah Al-Baqarah" class="ayah-next" href="/2/">&rarr;</a>
    </div>
    <div class="goto-ayah-wrapper">
        <div class="label-goto-ayah">Ke ayat</div>
        <select class="goto-ayah" id="goto-ayah">
            <option value="#no1">1</option><option value="#no2">2</option><option value="#no3">3</option><option value="#no4">4</option><option value="#no5">5</option><option value="#no6">6</option><option value="#no7">7</option>
        </select>
    </div>

    
        <div class="ayah" id="no1" title="Al-Fatihah,1,1" data-is-last-ayah="" data-next-ayah-number="2">
            <div class="ayah-text" dir="rtl"><p>بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيْمِ<span class="ayah-number" dir="ltr">1</span></p></div>
            <div class="ayah-toolbar">
                <a class="icon-ayah-toolbar icon-back-to-top" title="Kembali ke atas" href="#"><span class="icon-content">&#x21e7;</span></a>
                <a class="icon-ayah-toolbar icon-mark-ayah link-mark-ayah" title="Tandai terakhir dibaca" href="#"><span class="icon-content">&#x2713;</span></a>
                <a class="icon-ayah-toolbar icon-tafsir-ayah" title="Tafsir Ayat" href="/1/1/"><span class="icon-content">&#x273C;</span></a>
                <a class="icon-ayah-toolbar icon-play-audio murottal-audio-player" title="Audio Ayat"
                                            data-surah-number="1"
                                            data-ayah-number="1"
                                            data-next-ayah-number="2"
                                            data-next-surah-number="1"
                                            data-is-last-ayah=""
                                            data-from-tafsir-page="0"
                                            id="audio-1-1"><span class="icon-content">&#x25b6;</span></a>
            </div>
            <div class="ayah-translation"><p>Dengan nama Allah Yang Maha Pengasih, Maha Penyayang.</p></div>
        </div>


    <div class="ayah-prev-next-wrapper bottom">
        <a title="Sebelumnya Surah An-Nas" class="ayah-prev bottom" href="/114/">&larr;</a>
        <a title="Berikutnya Surah Al-Baqarah" class="ayah-next bottom" href="/2/">&rarr;</a>
    </div>
</div>
<div class="footer">
    <p>QuranWeb v1.7.2</p>
    <p>made with <span class="love">♥︎</span> by <a href="https://rioastamal.net">Rio Astamal</a></p>
</div>
<script type="text/javascript">
var murottalAudioElement = document.createElement('Audio');
var previousPlayedButton = null;
var murottalLoopMode = 'noloop';
var ayahSelection = [];

var afterAudioDoneCallback = function(e) {
    // &#x25b6; black right triangle
    var surahNumber = e.target.myCustomData.surahNumber;
    var ayahNumber = e.target.myCustomData.ayahNumber;
    var audioButton = e.target.myCustomData.audioButton;
    audioButton.innerHTML = '<span class="icon-content">&#x25b6;</span>';

    murottalAudioElement.loop = false;
    if (murottalLoopMode === 'surah') {
        if (audioButton.getAttribute('data-from-tafsir-page') == "1") {
            return;
        }

        var nextAyah = audioButton.getAttribute('data-next-ayah-number');
        if (audioButton.getAttribute('data-is-last-ayah') == "1") {
            nextAyah = 1;
        }
        document.getElementById('audio-' + surahNumber + '-' + nextAyah).click();

        // do not scroll if we are opening side menu
        if (window.location.hash.indexOf('#sidepage') == -1) {
            window.location.href = '#no' + nextAyah;
        }
    }

    if (murottalLoopMode === 'ayah-selection') {
        if (audioButton.getAttribute('data-from-tafsir-page') == "1") {
            return;
        }

        var currentIndexPosition = ayahSelection.indexOf(parseInt(ayahNumber));
        var nextAyah = ayahSelection[currentIndexPosition + 1];

        if (currentIndexPosition + 1 === ayahSelection.length) {
            nextAyah = ayahSelection[0];
        }

        // Prevent unknown ayat to be played
        if (document.getElementById('audio-' + surahNumber + '-' + nextAyah) === null) {
            return;
        }

        document.getElementById('audio-' + surahNumber + '-' + nextAyah).click();

        // do not scroll if we are opening side menu
        if (window.location.hash.indexOf('#sidepage') == -1) {
            window.location.href = '#no' + nextAyah;
        }
    }
}

/**
 * Function to pad string at beginning. With modification without String.repeat().
 *
 * https://github.com/uxitten/polyfill/blob/master/string.polyfill.js
 * https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/String/padStart
 *
 * @return String
 */
if (!String.prototype.padStart) {
    String.prototype.padStart = function padStart(targetLength, padString) {
        var targetLength = targetLength >> 0; //truncate if number, or convert non-number to 0;
        var padString = String(typeof padString !== 'undefined' ? padString : ' ');
        if (this.length >= targetLength) {
            return String(this);
        } else {
            targetLength = targetLength - this.length;
            var prefix = '';
            for (var i=0; i<targetLength; i++) {
                prefix += padString;
            }

            return prefix + String(this);
        }
    };
}

/**
 * @param String $value
 * @return Array
 */
function parseAyahSelection(value)
{
    var tmpSelection = [];
    var ayahSelection = [];

    var tmp = value.split(',');
    for (var i=0; i<tmp.length; i++) {
        if (tmp[i].indexOf('-') > -1) {
            var tmp2 = tmp[i].split('-');
            var start = parseInt(tmp2[0]);
            var end = parseInt(tmp2[1]);

            for (var j=start; j<=end; j++) {
                tmpSelection.push(j);
            }

            continue;
        }

        tmpSelection.push(parseInt(tmp[i]));
    }

    // Remove duplicate
    for (var i=0; i<tmpSelection.length; i++) {
        if (ayahSelection.indexOf(tmpSelection[i]) !== -1) {
            continue;
        }

        ayahSelection.push(tmpSelection[i]);
    }

    // Sort from lowest to highest
    return ayahSelection.sort(function(a, b) {
        return a - b;
    });
}


/**
 * Check exitense of a cookie.
 *
 * @param String name
 * @param String value
 * @return boolean
 */
function isCookieExists(name, value)
{
    if (document.cookie.split(';').filter(function(item) {
        if (typeof value === 'undefined') {
            return item.indexOf(name + '=') >= 0;
        }

        return item.indexOf(name + '=' + value) >= 0;
    }).length) {
        return true;
    }

    return false;
};

/**
 * Write cookie and set the expiration to forever. It will only write once.
 *
 * @param String name
 * @param String value
 * @param Boolean checkWithValue
 * @return void
 */
function writePermanentCookie(name, value, checkWithValue)
{
    var currentYear = (new Date()).getFullYear() + 3;
    var expires = (new Date(currentYear, 12, 12)).toUTCString();
    document.cookie = name + '=' + value + ';path=/;expires=' + expires;
};

/**
 * Apply night mode
 *
 * @param boolean night
 * @return void
 */
function applyNightMode(apply)
{
    var nightModeCss = 'nightmode';

    if (apply === false) {
        document.body.className = document.body.className.replace(nightModeCss, '');

        writePermanentCookie('nightMode', '0');
        return;
    }

    document.body.className = document.body.className + ' ' + nightModeCss;

    writePermanentCookie('nightMode', '1');
}

/**
 * Apply translation
 *
 * @param boolean apply
 * @return void
 */
function applyTranslation(apply)
{
    var notranslationCss = 'notranslation';

    if (apply === true) {
        document.body.className = document.body.className.replace(notranslationCss, '');

        writePermanentCookie('useTranslation', '1');
        return;
    }

    document.body.className = document.body.className + ' ' + notranslationCss;

    writePermanentCookie('useTranslation', '0');
}

/**
 * Apply on double click for ayah element
 *
 * @return void
 */
function applyClickForBookmark()
{
    var ayahNumberElements = document.getElementsByClassName('link-mark-ayah');
    var writeMarkedAyah = function(surahName, surahNumber, ayahNumber) {
        var marked = confirm('Tandai sebagai terakhir dibaca Surah ' + surahName + ' ayat ' + ayahNumber + '?');
        if (marked == false) {
            return;
        }

        var lastReadCookieValue = surahName + ',' + surahNumber.toString() + ',' + ayahNumber.toString();
        writePermanentCookie('lastRead', lastReadCookieValue);
        document.getElementById('sidepage-item-last-marked').innerHTML = 'Surah ' + surahName + ' ayat ' + ayahNumber;
        document.getElementById('last-read-link').href = '/' + surahNumber + '/#no' + ayahNumber;
    };

    var ayahInfo;
    for (var i=0; i<ayahNumberElements.length; i++) {
        ayahNumberElements[i].onclick = function(e)
        {
            ayahInfo = this.parentNode.parentNode.title.split(',');
            writeMarkedAyah(ayahInfo[0], ayahInfo[1], ayahInfo[2]);

            return false;
        }
    }

    if (!isCookieExists('lastRead')) {
        return;
    }

    ayahInfo = document.cookie.replace(/(?:(?:^|.*;\s*)lastRead\s*\=\s*([^;]*).*$)|^.*$/, "$1").split(',');
    document.getElementById('sidepage-item-last-marked').innerHTML = 'Surah ' + ayahInfo[0] + ' ayat ' + ayahInfo[2];
    document.getElementById('last-read-link').href = '/' + ayahInfo[1] + '/#no' + ayahInfo[2];
}

/**
 * Audio murottal are taken from everyayah.com. Currently only support one reciter.
 *
 * @param int surahNumber
 * @param int ayahNumber
 * @param HTMLAudioElement audioButton
 * @return void
 */
function playAudioMurottal(surahNumber, ayahNumber, audioButton)
{
    var reciterName = document.getElementById('murottal-reciter').value;
    var baseMurottalUrl = 'https://everyayah.com/data/' + reciterName + '/';
    var murottalFile = (parseInt(surahNumber) * 1000 + parseInt(ayahNumber)).toString();
    murottalFile = murottalFile.padStart(6, '0') + '.mp3';

    if (previousPlayedButton === audioButton && !murottalAudioElement.ended) {
        if (murottalAudioElement.paused) {
            murottalAudioElement.play();
            // Pause icon using double pipe character
            audioButton.innerHTML = '<span class="icon-content"><b>||</b></span>';
        } else {
            murottalAudioElement.pause();
            // pipe with black triangle icon
            audioButton.innerHTML = '<span class="icon-content">|&#x25b6;</span>';
        }

        return;
    }

    if (previousPlayedButton !== null) {
        // reset button back to Play icon
        previousPlayedButton.innerHTML = '<span class="icon-content">&#x25b6;</span>';
    }
    previousPlayedButton = audioButton;

    murottalAudioElement.src = baseMurottalUrl + murottalFile;
    murottalAudioElement.play();

    if (murottalLoopMode === 'ayah') {
        murottalAudioElement.loop = true;
    }

    // Pause icon using double pipe character
    audioButton.innerHTML = '<span class="icon-content"><b>||</b></span>';
    murottalAudioElement.myCustomData = {
        surahNumber: surahNumber,
        ayahNumber: ayahNumber,
        audioButton: audioButton
    }
    murottalAudioElement.removeEventListener('ended', afterAudioDoneCallback, false);
    murottalAudioElement.addEventListener('ended', afterAudioDoneCallback, false);
}

/**
 * Function apply function to play audio murottal
 *
 * @return void
 */
function applyClickForMurottal()
{
    var clickAudioElements = document.getElementsByClassName('murottal-audio-player');
    for (var i=0; i<clickAudioElements.length; i++) {
        clickAudioElements[i].onclick = function(e)
        {
            playAudioMurottal(
                this.getAttribute('data-surah-number'),
                this.getAttribute('data-ayah-number'),
                this
            );
        }
    }

    var murottalOptionElements = document.getElementsByName('murottal-mode');
    for (var i=0; i<murottalOptionElements.length; i++) {
        murottalOptionElements[i].onclick = function(e) {
            murottalLoopMode = this.value;

            writePermanentCookie('murottalMode', this.value);

            if (this.value === 'ayah') {
                murottalAudioElement.loop = true;
                return;
            }

            if (this.value === 'ayah-selection' && ayahSelection.length === 0) {
                return;
            }

            murottalAudioElement.loop = false;
        }

        if (isCookieExists('murottalMode', murottalOptionElements[i].value)) {
            murottalOptionElements[i].checked = true;
            murottalLoopMode = murottalOptionElements[i].value;
        }
    }

    if (isCookieExists('ayahSelection')) {
        var ayahSelectionInCookie = document.cookie.replace(/(?:(?:^|.*;\s*)ayahSelection\s*\=\s*([^;]*).*$)|^.*$/, "$1");
        document.getElementById('ayah-selection-input').value = ayahSelectionInCookie;
        ayahSelection = parseAyahSelection(ayahSelectionInCookie);
    }

    if (isCookieExists('reciterIndex')) {
        var reciterIndex = document.cookie.replace(/(?:(?:^|.*;\s*)reciterIndex\s*\=\s*([^;]*).*$)|^.*$/, "$1");
        document.getElementById('murottal-reciter').selectedIndex = parseInt(reciterIndex);
    }
}

document.getElementById('murottal-reciter').onchange = function(e)
{
    writePermanentCookie('reciterIndex', this.selectedIndex);
}

document.getElementById('ayah-selection-input').onkeyup = function(e)
{
    // Regex credit @see https://stackoverflow.com/a/45450540/2566677
    var ayatRegex = new RegExp(/^[0-9]+(?:-[0-9]+)?(,[0-9]+(?:-[0-9]+)?)*$/gm);
    if (!ayatRegex.test(this.value)) {
        this.className = this.className.replace(' input-error', '') + ' input-error';
        return;
    }

    this.className = this.className.replace(' input-error', '');
    ayahSelection = parseAyahSelection(this.value);
    writePermanentCookie('ayahSelection', this.value);
}

/**
 * Jump to particular ayah when select element changes
 */
var gotoAyahElement = document.getElementById('goto-ayah');
var onAyahPage = false;

if (gotoAyahElement !== null) {
    gotoAyahElement.onchange = function(e) {
        window.location.href = this.value;
    }

    // Apply selected attribute
    var gotoTafsirAyahElement = document.getElementsByClassName('goto-ayah-tafsir');
    if (gotoTafsirAyahElement.length > 0) {
        onAyahPage = true;
        var currentAyah = parseInt(window.location.pathname.split('/')[2]);
        var optionsEl = gotoTafsirAyahElement[0].options;

        for (var i=0; i<optionsEl.length; i++) {
            if (currentAyah - 1 === i) {
                optionsEl[i].selected = true;
            }
        }
    }

    // Scroll to Next ayah on click
    var allAyah = document.querySelectorAll('.ayah-text');
    for (var i=0; i<allAyah.length; i++) {
        allAyah[i].addEventListener('click', function(el) {
            window.location.href = '#no' + this.parentNode.getAttribute('data-next-ayah-number');
        });
    }

    // Go to next ayah when press ENTER
    document.onkeyup = function(e) {
        if (e.which === 13) { /* Deprecated - but I need to support my BB10 :) */
            currentAyah = parseInt(window.location.hash.split('#no')[1]) || 0

            if (currentAyah === allAyah.length) {
                return;
            }

            e.preventDefault();
            window.location.href = '#no' + (currentAyah + 1);
        }
    }
}

document.getElementById('translation').onclick = function(e)
{
    if (this.checked) {
        applyTranslation(true);
        return;
    }

    applyTranslation(false);
}

document.getElementById('nightmode').onclick = function(e)
{
    if (this.checked) {
        applyNightMode(true);
        return;
    }

    applyNightMode(false);
}

var searchElement = document.getElementById('search-keywords');

if (searchElement !== null) {
    document.getElementById('search-keywords').onkeyup = function(e)
    {
        var surahList = document.getElementsByClassName('surah-index-link');
        var keyword = this.value.toLowerCase();

        for (var i=0; i<surahList.length; i++) {
            surahList[i].parentNode.style.display = 'block';

            if (surahList[i].getAttribute('data-keywords').toLowerCase().indexOf(keyword) === -1) {
                surahList[i].parentNode.style.display = 'none';
            }
        }
    }
}

document.addEventListener('DOMContentLoaded', function(e)
{
    applyClickForBookmark();
    applyClickForMurottal();

    if (isCookieExists('nightMode', '1')) {
        applyNightMode(true);
        document.getElementById('nightmode').checked = true;
    }

    if (isCookieExists('nightMode', '0')) {
        applyNightMode(false);
        document.getElementById('nightmode').checked = false;
    }

    // Translation is enabled by default
    if (!onAyahPage) {
        if (isCookieExists('useTranslation', '0')) {
            applyTranslation(false);
            document.getElementById('translation').checked = false;
        }
    }

    if (onAyahPage) {
        document.getElementById('translation').disabled = true;
    }
});
</script>
<script>
    document.addEventListener("DOMContentLoaded", function() {
      const surahContainer = document.getElementById("surahContainer");

      // Function to get URL parameters
      function getUrlParameter(name) {
        name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
        const regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
        const results = regex.exec(location.search);
        return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
      }

      // Get suratNumber from the URL parameter
      const suratNumber = getUrlParameter('selectedSurah') || 1;

      let ayatNumber = 1;

      function fetchAyat() {
        const apiUrl = `https://api.myquran.com/v2/quran/ayat/${suratNumber}/${ayatNumber}`;

        fetch(apiUrl)
          .then(response => {
            if (!response.ok) {
              throw new Error(`API Error: ${response.statusText}`);
            }
            return response.json();
          })
          .then(data => {
            const ayat = data.data[0];

            const ayatContainer = document.createElement("div");
            ayatContainer.innerHTML = `
            <div class="container mt-5">
            <div class="shadow p-3 mb-2 bg-body rounded"> <p class="text-base text-end">${ayat.arab} (${ayat.ayah})</p>
        <p class="text-sm text-justify mt-3 mb-3 ">${ayat.ayah}.${ayat.latin}</p>
        <p class="text-sm text-justify mt-3 mb-3 ">${ayat.text}</p>
        <audio controls>
            <source src="${ayat.audio}" type="audio/mp3">
            Your browser does not support the audio element.
        </audio>
            </div>
       
    </div>

  
            `;
            surahContainer.appendChild(ayatContainer);

            // Increment ayatNumber for the next fetch
            ayatNumber++;

            // Call fetchAyat recursively
            fetchAyat();
          })
          .catch(error => {
            console.error("Error fetching data:", error);
            // Handle the error or stop the recursion
          });
      }

      // Start fetching ayat
      fetchAyat();
    });
  </script>
</body>
</html>
